﻿using System;
namespace program
{
    public class PhonesStore
    {
        public const int maxSize = 20;
        private Phone[] arr;
        private int current;
        private string nameStore;
        public PhonesStore(string nameStore)
        {
            this.nameStore = nameStore;
            this.arr = new Phone[maxSize];
            this.current = 0;
        }

        public void Print()
        {
            for (int i = 0; i < this.current; i++)
            {//if (this.arr[i].GetCompany().Equals("LG"))
                if (this.arr[i].GetCompany() == "LG")
                    Console.WriteLine($"The price is {this.arr[i].GetSalary()}");
            }
        }



        public int Found()
        {
            int count = 0;
            for (int i = 0; i < current; i++)
            {
                if (this.arr[i].GetWaterProof() && this.arr[i].Expensive())
                    count++;
            }
            return count;
        }


        public void AddPhone(Phone newPhone)
        {
            //this.arr[current++] = newPhone;
            this.arr[current] = newPhone;
            this.current++;
        }


        public override string ToString()
        {
            string str="";
            for (int i = 0; i < this.current; i++)
            {
                str = str + arr[i].ToString()+"\n";
            }
            return str;
        }
    }
}

