﻿using System;
namespace program
{
    public class Phone//عنوان الفئة
    {
        //صفات الفئة
        private int code;
        public string company;
        public int salary;
        public bool waterProof;

       

         public int GetCode()
        {
            return this.code;
        }
        public void SetCode(int code)
        {
            this.code=code;
        }

        public string GetCompany()
        {
            return this.company;
        }
        public void SetCompany(string company)
        {
            this.company = company;
        }


        public int GetSalary()
        {
            return this.salary;
        }
        public void SetSalary(int salary)
        {
            this.salary = salary;
        }

        public bool GetWaterProof()
        {
            return this.waterProof;
        }
        public void SetWaterProof(bool waterProof)
        {
            this.waterProof = waterProof;
        }

        public Phone()
        {
            
        }

        public Phone(int code, string company, int salary, bool waterProof)
        {
            this.code = code;
            this.company = company;
            this.salary = salary;
            this.waterProof = waterProof;
        }

        public bool Expensive()
        {
            return this.GetSalary() > 3000;
        }

      public bool CheckDiscount()
        {
            return (this.GetSalary() >= 3000 && this.GetSalary() <= 5000);
      
        }
        public override string ToString()
        {
            return $"code{this.code}|company{this.company}|salary:{this.salary}|water proof:{this.waterProof}";
        }
    }
}

