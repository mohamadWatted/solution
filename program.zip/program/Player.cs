﻿using System;
namespace program
{
    public class Player
    {
        private int code;
        private string name;
        private int salary;
        private int stars;

        //تطبيق العمليات للفئة player
        public Player(int code,string name,int salary,int stars)
        {
            this.code = code;
            this.name = name;
            this.salary = salary;
            this.stars = stars;
        }

        public static int Something()
        {
            return 1;
        }
        public Player(int code,string name,int salary)
        {
            this.code = code;
            this.name = name;
            this.salary = salary;
            this.stars = 5;
        }

        public void AddStar()
        {
            if (this.stars < 5)
                this.stars++;
        }

        public override string ToString()
        {
            return $"{this.code}|{this.name}|{this.salary}|{this.stars}";
        }


        public int GetCode()
        {
            return this.code;
        }
        public void SetCode(int code)
        {
            this.code = code;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public int GetSalary()
        {
            return this.salary;
        }
        public void SetSalary(int salary)
        {
            this.salary = salary;
        }
        public int GetStars()
        {
            return this.stars;
        }
        public void SetStars(int stars)
        {
            this.stars = stars;
        }


    }
}

