﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace program
{
    public class program_
    {
        public static void Main(string[] args)
        {
            string company;
            int numPhones, code, salary;
            bool waterproof;
            string nameStore;
            Console.WriteLine("Enter the name of store:");
            nameStore = Console.ReadLine();

            PhonesStore phoneStore = new PhonesStore(nameStore);

            Console.WriteLine("Enter the number of phones between 1 to 20");
            numPhones = int.Parse(Console.ReadLine());
            for(int i = 1; i <= numPhones; i++)
            {
                Console.WriteLine("Enter Phone Details:");
                code = int.Parse(Console.ReadLine());
                salary = int.Parse(Console.ReadLine());
                company = Console.ReadLine();
                waterproof = bool.Parse(Console.ReadLine());
                Phone phone = new Phone(code,company,salary,waterproof);
                phoneStore.AddPhone(phone);
            }

           
                Console.WriteLine(phoneStore.ToString());
            


            //Player p1 = new Player(1111, "rod", 15000, 4);
            //Player p2 = new Player(2222, "sam", 20000);

            //Console.WriteLine("player 1=" + p1);
            //Console.WriteLine("player 2=" + p2);

            //if(p1.GetStars()==5)
            //    Console.WriteLine("ok");
            //else
            //    Console.WriteLine("not ok");
            //p1.AddStar();

            //if(p1.GetStars()+p2.GetStars()==10)
            //    Console.WriteLine("ok");
            //else
            //    Console.WriteLine("not ok");



            Console.ReadKey();

        }
    }
}