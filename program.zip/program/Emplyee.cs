﻿using System;
namespace program
{
    public class Employee
    {
        private string name;
        private int salary;
        private int seniority;
        private int academy;

        //افحص الحصة الجاي جدول المتابعة
    }
}

